/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PedidosLibros;

/**
 *
 * @author Ignacio
 */
public class mein {
    
    public static void main(String args[]) {
        
    GestionUsuario<Usuario> gestionUsuarios = new GestionUsuario<>();
    Usuario us1 = new Usuario("123","mike","san pedro","123","ignacio@");
    Usuario us2 = new Usuario("1233","mike","san pedro","123","ignacio@");
    Usuario us3 = new Usuario("1234","mike","san pedro","123","ignacio@");
    
    gestionUsuarios.agregar(us1);
    gestionUsuarios.eliminar(us2);


    System.out.println(gestionUsuarios.toString());
    
    
    
    
}}
