/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PedidosLibros;

import logica.model.libreria.Libreria;
import logica.model.libreria.Libro;
import logica.model.libreria.Usuario;
import estructura.*;
import logica.modelo.usuario.GestionCompra;
import logica.modelo.usuario.GestionLibreria;
import Extras.GestionUsuario;

/**
 *
 * @author Ignacio
 */
public class VirtualLibraryTEC {
    
    private GestionCompra<Compra> compras;
    
    
    private GestionUsuario<Usuario> usuarios;
    private GestionLibreria<Libreria> librerias;

    public void comprarLibro(Usuario usuario, Libreria libreria, Libro libro, int cantidad){
    if (usuarios.consultar(usuarios) != null && librerias.consultar(libreria) != null && librerias.consultar(libreria).getLibros().consultar(libro) != null){
        compras.agregar(new Compra(usuario, libreria, libro, cantidad));
        libreria.getLibros().consultar(libro).setCantidadDisponible(libreria.getLibros().consultar(libro).getCantidadDisponible()-cantidad);
    }
    }
    
}
