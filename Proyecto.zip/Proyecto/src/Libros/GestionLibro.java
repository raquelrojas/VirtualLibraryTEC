/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Libros;

import Libreria.Libreria;
import estructura.Lista;
import Libros.Libros;
import estructura.Nodo;
import java.util.logging.Level;
import java.util.logging.Logger;
import Libros.GestionLibro;
import modelo.enums.CategoriasLibros;

public class GestionLibro{
     private Lista<Libros> libros;

	public Lista<Libros> getLibros() {
		return libros;
	}

	public void setLibros(Lista<Libros> Libros) {
		this.libros = Libros;
	}

	public GestionLibro() {
		this.libros = new Lista<Libros>();
	}

	private Libros buscar(String issn) {
        Nodo<Libros> temp = libros.getInicio();
        for (int i = 0; i < libros.getSize(); i++) {
            if (temp.getElemento().getIssn().equals(issn)) {
                break;
            } else {
                temp = temp.getNodoSig();
            }
        }
        return temp.getElemento();
    }

    public void crearLibros(String issn, String nombre, CategoriasLibros tema, int cantvendida, int cantdisponible, String descripcion, double precio) {
        Libros newLibro = new Libros(issn, nombre, tema, cantvendida, cantdisponible, descripcion, precio);
        this.libros.insertarDetras(newLibro);
    }

    public void eliminarLibros(String issn) throws Exception {
        libros.eliminarNodoEspecifico(buscar(issn));
    }

    public String consultarLibreria() {
        return libros.toString();
    }
    
    
    
}
