/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Libros;

import estructura.Lista;
import Libros.Libros;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestionLibro<X>{
    private Lista<X> listaGestionada;

    public Lista<X> getListaGestionada() {
        return listaGestionada;
    }

    public void setListaGestionada(Lista<X> listaGestionada) {
        this.listaGestionada = listaGestionada;
    }

    @Override
    public String toString() {
        return "GestionGenerica{" + "listaGestionada=" + listaGestionada + '}';
    }

    public GestionLibro() {
        this.listaGestionada = new Lista<>();
        
    }
    
    public void agregar(X elemento){
        listaGestionada.insertarDetras(elemento);
    }    
public X consultar(X elemento){
        return listaGestionada.consultar(elemento);
    }
   public void modificar(X oldElement, X newElement){
     listaGestionada.Modificar(oldElement, newElement);
     }
   
   public void eliminar(X elemento) throws Exception{
       listaGestionada.eliminarNodoEspecifico(elemento);

     }
    
    
    
    
    
}
