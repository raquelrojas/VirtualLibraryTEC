/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Libros;

import Extras.GeneradorCodigos;
import modelo.enums.CategoriasLibros;

public class Libros {
    String issn;
    int cantvendida,cantdisponible;
    double precio;
    String nombre,descripcion;
    CategoriasLibros tema;
    GeneradorCodigos codigoRandom;

    
    public void setIssn(String newissn){
    issn = newissn;}
    
    public void setCantvendida(int newcant){
    cantvendida = newcant;}
    
    public void sentCantdisponible(int newdisponible){
    cantdisponible = newdisponible;}
    
    public void setPrecio(int newprecio){
    precio = newprecio;}
    
    public void setNombre(String newnombre){
    nombre = newnombre;}
    
    
    public void setDescripcion(String newdescrip){
    descripcion = newdescrip;}
    
    public String getIssn(){
    return issn;}
    
    public int getCantvendida(){
    return cantvendida;}
    
    public int getCantdisponible(){
    return cantdisponible;}
    
    public double getPrecio(){
    return precio;}
    
    public String getNombre(){
    return nombre;}
    
    public String getDescripcion(){
    return descripcion;}
    
     public void Libro(String nombre, CategoriasLibros tema, String descripcion , int cantvendida, int cantdisponible, double precio) {
        this.nombre = nombre;
        this.tema = tema;
        this.cantvendida = cantvendida;
        this.cantdisponible = cantdisponible;
        this.precio = precio;
        this.descripcion = descripcion;
        this.codigoRandom = new Extras.GeneradorCodigos(5);
        this.issn = tema.getCodigoCategoria() +"-"+ codigoRandom;
                
    }
    @Override
    public String toString() {
        return "Issn=" + issn + ", Cant. vendida =" + cantvendida + ", cant.disponible=" + cantdisponible   + "\n";
    }

    }

    

